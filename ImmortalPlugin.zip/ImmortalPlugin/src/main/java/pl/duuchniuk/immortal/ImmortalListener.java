package pl.duuchniuk.immortal;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

public class ImmortalListener implements Listener {
    
    private final ImmortalManager immortalManager;
    
    public ImmortalListener(ImmortalManager immortalManager) {
        this.immortalManager = immortalManager;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getEntity();
        
        if (!immortalManager.hasImmortal(player)) {
            return;
        }
        
        if (isHoldingTotem(player)) {
            return;
        }
        
        double currentHealth = player.getHealth();
        double damage = event.getFinalDamage();
        double healthAfterDamage = currentHealth - damage;
        double minHealth = 1.0;
        
        if (healthAfterDamage < minHealth) {
            event.setDamage(currentHealth - minHealth);
        }
    }
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        
        if (immortalManager.hasImmortal(player) && !isHoldingTotem(player)) {
            event.setCancelled(true);
            player.setHealth(1.0);
        }
    }
    
    private boolean isHoldingTotem(Player player) {
        ItemStack mainHand = player.getInventory().getItemInMainHand();
        ItemStack offHand = player.getInventory().getItemInOffHand();
        
        return (mainHand != null && mainHand.getType() == Material.TOTEM_OF_UNDYING) ||
               (offHand != null && offHand.getType() == Material.TOTEM_OF_UNDYING);
    }
}

