package pl.duuchniuk.immortal;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ImmortalCommand implements CommandExecutor {
    
    private final ImmortalManager immortalManager;
    
    public ImmortalCommand(ImmortalManager immortalManager) {
        this.immortalManager = immortalManager;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        
        if (!sender.hasPermission("immortal.use")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }
        
        if (args.length != 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /immortal <player>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[0]);
        
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player " + args[0] + " is not online!");
            return true;
        }
        
        if (immortalManager.hasImmortal(target)) {
            immortalManager.removeImmortal(target);
            sender.sendMessage(ChatColor.GREEN + "Immortality for " + target.getName() + " has been disabled!");
            target.sendMessage(ChatColor.YELLOW + "Your immortality has been disabled!");
        } else {
            immortalManager.addImmortal(target);
            sender.sendMessage(ChatColor.GREEN + "Immortality for " + target.getName() + " has been enabled!");
            target.sendMessage(ChatColor.YELLOW + "You received immortality! Your HP cannot drop below half a heart (unless you hold a totem)!");
        }
        
        return true;
    }
}
