package pl.duuchniuk.immortal;

import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ImmortalManager {
    
    private final Set<UUID> immortalPlayers;
    
    public ImmortalManager() {
        this.immortalPlayers = new HashSet<>();
    }
    
    public void addImmortal(Player player) {
        immortalPlayers.add(player.getUniqueId());
    }
    
    public void removeImmortal(Player player) {
        immortalPlayers.remove(player.getUniqueId());
    }
    
    public boolean hasImmortal(Player player) {
        return immortalPlayers.contains(player.getUniqueId());
    }
    
    public boolean hasImmortal(UUID uuid) {
        return immortalPlayers.contains(uuid);
    }
    
    public void clearAll() {
        immortalPlayers.clear();
    }
    
    public int getImmortalCount() {
        return immortalPlayers.size();
    }
}
