package pl.duuchniuk.immortal;

import org.bukkit.plugin.java.JavaPlugin;

public final class ImmortalPlugin extends JavaPlugin {

    private ImmortalManager immortalManager;

    @Override
    public void onEnable() {
        immortalManager = new ImmortalManager();
        getCommand("immortal").setExecutor(new ImmortalCommand(immortalManager));
        getServer().getPluginManager().registerEvents(new ImmortalListener(immortalManager), this);
        getLogger().info("ImmortalPlugin enabled!");
    }

    @Override
    public void onDisable() {
        if (immortalManager != null) {
            immortalManager.clearAll();
        }
        getLogger().info("ImmortalPlugin disabled!");
    }
}

